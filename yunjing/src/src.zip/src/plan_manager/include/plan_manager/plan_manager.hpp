#ifndef _PLAN_MANAGER_HPP_
#define _PLAN_MANAGER_HPP_

#include "model_gazebo/world2oct.h"
#include "visualizer/visualizer.hpp"
#include "front_end/kino_astar.h"
#include "geometry_msgs/PoseStamped.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/Twist.h"
#include "back_end/gcopter.hpp"
#include "tf/tf.h"
#include "tf/transform_datatypes.h"

class PlanManager
{
  private:
    ros::NodeHandle nh_;

    std::shared_ptr<World2oct> world2oct_;
    std::shared_ptr<Visualizer> visualizer_;
    std::shared_ptr<KinoAstar> kinoastar_;
    std::shared_ptr<Gcopter> gcopter_;


    ros::Subscriber goal_sub_;
    ros::Subscriber position_sub_;
    // ros::Subscriber current_state_sub_;

    ros::Publisher cmd_pub_;

    Eigen::Vector4d current_state_;
    Eigen::Vector2d current_control_;
    Eigen::Vector4d goal_state_;

    double dis_thre_;



  public:
    PlanManager(ros::NodeHandle nh){
      nh_ = nh;
      
      world2oct_ = std::make_shared<World2oct>(nh);
      visualizer_ = std::make_shared<Visualizer>(nh);
      kinoastar_ = std::make_shared<KinoAstar>(nh,world2oct_);
      gcopter_ = std::make_shared<Gcopter>(Config(ros::NodeHandle("~")), nh_, world2oct_,kinoastar_);
      ROS_INFO("kinoastar_->init();!!!!!!!!!!!!!");
      kinoastar_->init();

      goal_sub_ = nh_.subscribe<geometry_msgs::PoseStamped>("/move_base_simple/goal",1,&PlanManager::goal_callback,this);
      position_sub_ = nh_.subscribe<nav_msgs::Odometry>("/vrpn_client_node/yunjing/pose",1,&PlanManager::pose_callback,this);
      cmd_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel",1);

      nh_.param<double>(ros::this_node::getName()+ "/dis_thre",dis_thre_,0.01);
    
      // current_state_<<-4,2.5,0,0;
      // current_control_<<0,0;
      current_state_<<5.0,5.0,0,0;
      current_control_<<0,0;
      ros::Duration l(1);
      l.sleep();
      visualizer_->pub_singul_car(current_state_);
      
      // current_state_<<-2.00710201263, 3.01263618469, -0.5,0;
      // current_control_<<0,0;
    }

    ~PlanManager(){
      world2oct_->~World2oct();
      visualizer_->~Visualizer();
      kinoastar_->~KinoAstar();
    }

    void init(){
      kinoastar_->init();
    }

    void pose_callback(const nav_msgs::Odometry::ConstPtr &msg){
      double yaw = tf::getYaw(msg->pose.pose.orientation);
      current_state_<<msg->pose.pose.position.x, msg->pose.pose.position.y, yaw, 0;
      visualizer_->pub_singul_car(current_state_);
    }

    void goal_callback(const geometry_msgs::PoseStamped::ConstPtr &msg){
      std::cout << "get goal!" << std::endl;
      visualizer_->finalnodePub(msg);
      goal_state_ <<  msg->pose.position.x, msg->pose.position.y,
                  tf::getYaw(msg->pose.orientation), 1.0e-2;
      // goal_state_ << 2.24416303635,1.28502774239, 3.1415926535, 0.01;
      std::cout<<goal_state_.transpose()<<std::endl;
      std::cout<<"end_pt: "<<goal_state_.transpose()<<std::endl;

      int count = 0;
      while((current_state_.head(2)-goal_state_.head(2)).norm()>dis_thre_){
        ROS_INFO("finding Astar Road!");
        findAstarRoad();
        count++;
        ros::Time current = ros::Time::now();
        gcopter_->minco_plan();
        ROS_INFO("\033[41;37m all of minco plan time:%f \033[0m", (ros::Time::now()-current).toSec());
        ROS_INFO("mincoCarPub start!");
        visualizer_->mincoCarPub(gcopter_->final_trajes, gcopter_->final_singuls, gcopter_->offsetx);
        std::cout<<goal_state_.transpose()<<std::endl;
        if(count == 5){
          ROS_ERROR("count is 50, cannot find road, break!");
          break;
        }
      }

      // current_state_ = goal_state_;
    }

    void findAstarRoad(){
      kinoastar_->reset();
      ros::Time current = ros::Time::now();
      kinoastar_->search(goal_state_,current_state_,current_control_);
      ROS_INFO("kinoastar time:%lf", (ros::Time::now()-current).toSec());
      if(kinoastar_->has_path_){
        kinoastar_->getKinoNode();
        
        visualizer_->kinoastarPathPub(kinoastar_->path_nodes_);
        visualizer_->kinoastarFlatPathPub(kinoastar_->flat_trajs_);
      }
    }

    void pub_cmd_vel(const std::vector<Trajectory<5, 2>> &final_trajes, const Eigen::VectorXi &final_singuls, const double &offsetx){
      geometry_msgs::Twist cmd_vel;
      
      if(final_trajes.size()!=final_singuls.size()){
        ROS_ERROR("[mincoCarPub] Input size ERROR !!!!");
      }
      int traj_size = final_trajes.size();
      double total_time;
      Eigen::VectorXd traj_time;
      traj_time.resize(traj_size);
      for(int i=0; i<traj_size; i++){
        traj_time[i] = final_trajes[i].getTotalDuration();
      }
      total_time = traj_time.sum();

      int index = 0;
      Eigen::VectorXd currPos, currVel, currAcc, currJer, currSna;
      Eigen::Vector2d offset;
      double current;
      offset << offsetx, 0;

      Eigen::Matrix2d B_h;
      B_h << 0,-1,1,0;
      
      cmd_vel.angular.x = 0;
      cmd_vel.angular.y = 0;
      cmd_vel.linear.z = 0;
      ros::Time start = ros::Time::now();
      for(current = (ros::Time::now()-start).toSec(); current<total_time; current = (ros::Time::now()-start).toSec()){
        double index_time = 0;
        for( index = 0; index<traj_size; index++){
          if(current > index_time && current < index_time + traj_time[index] )
            break;
          index_time += traj_time[index];
        }
        currPos = final_trajes[index].getPos(current-index_time);
        currVel = final_trajes[index].getVel(current-index_time);
        currAcc = final_trajes[index].getAcc(current-index_time);

        if(currVel.norm() < 1e-4)
          currVel = currVel/currVel.norm() * 1e-4;

        double yaw = atan2(currVel.y(),currVel.x());
        int singuls = final_singuls[index];
        if(singuls<0){
          yaw += M_PI;
        }
        Eigen::Matrix2d R;
        R<<cos(yaw),-sin(yaw),sin(yaw),cos(yaw);

        double omega = 1.0/currVel.squaredNorm()*currAcc.transpose()*B_h*currVel;

        cmd_vel.linear.x = currVel.x();
        cmd_vel.linear.y = currVel.y();
        cmd_vel.angular.z = omega;

        cmd_pub_.publish(cmd_vel);

      }
      cmd_vel.linear.x = 0;
      cmd_vel.linear.y = 0;
      cmd_vel.angular.z = 0;
      cmd_pub_.publish(cmd_vel);

    }
};


#endif