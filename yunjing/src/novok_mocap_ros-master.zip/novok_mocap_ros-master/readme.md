本包是给nokov动捕系统使用的ROS包，基于vrpn魔改

使用前需要执行

`sudo apt-get install ros-ROSVERSION-vrpn`

附带的ekf_pose是和px4controller包里的是一样的，接收odometry类型数据